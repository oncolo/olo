// GLOBAL SCRIPT FOR WUBE BEREHA (PREMIUM)

document.addEventListener('DOMContentLoaded', () => {
    const body = document.body;
    const mainHeader = document.getElementById('main-header-premium');
    const themeSwitcher = document.getElementById('theme-switcher');
    const themeIcon = themeSwitcher ? themeSwitcher.querySelector('i') : null;
    const langSwitcherBtn = document.getElementById('lang-switcher-btn');
    const langDropdown = document.getElementById('lang-dropdown');
    const pagePreloader = document.getElementById('page-preloader');
    const burgerMenu = document.getElementById('burger-menu-premium');
    const mobileNavPanel = document.getElementById('mobile-nav');
    const closeMobileMenuButton = document.getElementById('close-mobile-menu-button');
    let bodyOverlay; // To be created dynamically

    // 1. Preloader
    if (pagePreloader) {
        window.addEventListener('load', () => {
            setTimeout(() => {
                pagePreloader.style.opacity = '0';
                pagePreloader.style.visibility = 'hidden';
                if (pagePreloader.contains(pagePreloader.querySelector('.preloader-spinner'))) { // check if spinner exists
                    pagePreloader.querySelector('.preloader-spinner').style.animationPlayState = 'paused';
                }
                pagePreloader.addEventListener('transitionend', () => {
                    if (pagePreloader) pagePreloader.style.display = 'none';
                }, { once: true });
            }, 300); // Small delay for visual smoothness
        });
    }

    // 2. Theme Switcher
    function applyTheme(theme) {
        body.setAttribute('data-theme', theme);
        if (themeIcon) themeIcon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        localStorage.setItem('wubeBerehaTheme_v2', theme); // Using a more specific key

        // Update CSS variables for current theme (important for elements not directly using data-theme selectors)
        if (theme === 'dark') {
            document.documentElement.style.setProperty('--current-bg-main', 'var(--bg-color-dark)');
            document.documentElement.style.setProperty('--current-bg-card', 'var(--bg-color-dark-alt)');
            document.documentElement.style.setProperty('--current-text-primary', 'var(--text-color-primary-dark)');
            document.documentElement.style.setProperty('--current-text-secondary', 'var(--text-color-secondary-dark)');
            document.documentElement.style.setProperty('--current-border-color', 'var(--border-color-dark)');
            document.documentElement.style.setProperty('--current-shadow-color', 'var(--shadow-color-dark)');
        } else {
            document.documentElement.style.setProperty('--current-bg-main', 'var(--bg-color-light-alt)');
            document.documentElement.style.setProperty('--current-bg-card', 'var(--bg-color-light)');
            document.documentElement.style.setProperty('--current-text-primary', 'var(--text-color-primary-light)');
            document.documentElement.style.setProperty('--current-text-secondary', 'var(--text-color-secondary-light)');
            document.documentElement.style.setProperty('--current-border-color', 'var(--border-color-light)');
            document.documentElement.style.setProperty('--current-shadow-color', 'var(--shadow-color-light)');
        }
    }

    const savedTheme = localStorage.getItem('wubeBerehaTheme_v2') || 'light';
    applyTheme(savedTheme);

    if (themeSwitcher) {
        themeSwitcher.addEventListener('click', () => {
            const newTheme = body.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
            applyTheme(newTheme);
        });
    }

    // 3. Language Switcher
    function updateLangSwitcherButton(languageCode) {
        if (langSwitcherBtn) {
            const langName = languageCode.toUpperCase();
            langSwitcherBtn.innerHTML = `${langName} <i class="fas fa-chevron-down"></i>`;
        }
    }
    
    function setPageLanguage(languageCode) {
        document.documentElement.lang = languageCode;
        localStorage.setItem('pageLanguage', languageCode);
        updateLangSwitcherButton(languageCode);

        // Translate page content
        const elementsToTranslate = document.querySelectorAll('[data-lang-key]');
        elementsToTranslate.forEach(el => {
            const key = el.dataset.langKey;
            let value = translations[languageCode] && translations[languageCode][key];
            // Only replace if value is not empty, not a placeholder, and not the same as the current HTML
            if (value && value.trim() !== '' && !/^ገንቢ \d+ ስም$/.test(value) && value.trim() !== el.textContent.trim()) {
                if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                    if(el.hasAttribute('data-lang-key-placeholder')) {
                        el.placeholder = value;
                    } else {
                        el.value = value;
                    }
                } else {
                    el.innerHTML = value;
                }
            } // else: do not overwrite the HTML if translation is missing, placeholder, or matches current content
        });
         // Update preloader text if it's still visible (though unlikely by this point)
        if (pagePreloader && pagePreloader.style.visibility !== 'hidden') {
            const preloaderTextElement = pagePreloader.querySelector('p[data-lang-key="loaderLoadingPage"]');
            if (preloaderTextElement) {
                 const key = preloaderTextElement.dataset.langKey;
                 if (translations[languageCode] && translations[languageCode][key]) {
                    preloaderTextElement.textContent = translations[languageCode][key];
                 } else if (translations['am'] && translations['am'][key]) {
                    preloaderTextElement.textContent = translations['am'][key];
                 }
            }
        }

        // Update any date formats or other language-specific elements if necessary
        // Example: document.getElementById('current-year-footer-premium').textContent = new Date().getFullYear();
    }

    const savedLanguage = localStorage.getItem('pageLanguage') || 'am';
    setPageLanguage(savedLanguage);

    if (langSwitcherBtn && langDropdown) {
        langSwitcherBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            langDropdown.classList.toggle('show');
        });

        langDropdown.addEventListener('click', (e) => {
            if (e.target.tagName === 'A' && e.target.dataset.lang) {
                e.preventDefault();
                setPageLanguage(e.target.dataset.lang);
                langDropdown.classList.remove('show');
            }
        });
    }
    // Close dropdown if clicked outside
    document.addEventListener('click', (e) => {
        if (langDropdown && langDropdown.classList.contains('show') && !langSwitcherBtn.contains(e.target)) {
            langDropdown.classList.remove('show');
        }
    });


    // 4. Header Scroll Behavior
    if (mainHeader) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                mainHeader.classList.add('scrolled');
            } else {
                mainHeader.classList.remove('scrolled');
            }
        });
    }

    // 5. Mobile Navigation
    function createBodyOverlay() {
        if (!document.querySelector('.body-overlay')) {
            bodyOverlay = document.createElement('div');
            bodyOverlay.className = 'body-overlay';
            body.appendChild(bodyOverlay);
            bodyOverlay.addEventListener('click', toggleMobileNav); // Close nav on overlay click
        } else {
            bodyOverlay = document.querySelector('.body-overlay');
        }
    }

    function toggleMobileNav() {
        if (!bodyOverlay) createBodyOverlay(); // Create overlay if it doesn't exist

        const isOpen = mobileNavPanel.classList.contains('open');
        if (isOpen) {
            mobileNavPanel.classList.remove('open');
            bodyOverlay.classList.remove('active');
            body.classList.remove('no-scroll');
            if (burgerMenu) burgerMenu.setAttribute('aria-expanded', 'false');
        } else {
            mobileNavPanel.classList.add('open');
            bodyOverlay.classList.add('active');
            body.classList.add('no-scroll');
            if (burgerMenu) burgerMenu.setAttribute('aria-expanded', 'true');
        }
    }

    if (burgerMenu && mobileNavPanel) {
        burgerMenu.addEventListener('click', toggleMobileNav);
        burgerMenu.setAttribute('aria-expanded', 'false');
        burgerMenu.setAttribute('aria-controls', 'mobile-nav');
    }
    if (closeMobileMenuButton) {
        closeMobileMenuButton.addEventListener('click', toggleMobileNav);
    }
    // Close mobile nav when a link is clicked
    if (mobileNavPanel) {
        mobileNavPanel.addEventListener('click', (e) => {
            if (e.target.matches('.mobile-nav-link')) {
                toggleMobileNav();
            }
        });
    }

    // 6. Smooth Scrolling & Active Nav Link Highlighting (for single-page navigation)
    const navLinks = document.querySelectorAll('#main-nav-premium .nav-link[href^="#"], .mobile-nav-list .mobile-nav-link[href^="#"]');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            if (targetId.startsWith('#') && targetId.length > 1) { // Basic check for internal link
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    // e.preventDefault(); // Prevent default only if it's truly a same-page anchor
                    // Smooth scroll handled by CSS html { scroll-behavior: smooth; }
                    // Logic for active class update can be more complex if sections overlap significantly
                }
            }
        });
    });

    // Update active nav link on scroll (simplified for sections)
    const sections = document.querySelectorAll('main section[id]');
    window.addEventListener('scroll', () => {
        let currentSectionId = '';
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            if (pageYOffset >= sectionTop - (mainHeader ? mainHeader.offsetHeight : 70) - 50) { // Adjusted offset
                currentSectionId = section.getAttribute('id');
            }
        });

        navLinks.forEach(link => {
            link.classList.remove('active');
            const href = link.getAttribute('href');
            // Check if href is not null and is a valid selector before querySelector
            if (href && href.startsWith('#') && href.length > 1) {
                if (href.substring(1) === currentSectionId) {
                    link.classList.add('active');
                }
            } else if (href && document.querySelector(`[data-section="${currentSectionId}"]`)?.getAttribute('href') === href) {
                 // Fallback for links that might not directly match section ID but have data-section
                link.classList.add('active');
            }
        });
        // Special handling for pages that are not single-page (e.g. suites.html, contact.html)
        // This is handled by adding 'active' class directly in HTML or by server-side logic typically
    });


    // 7. Custom Cursor
    const cursorDot = document.querySelector("[data-cursor-dot]");
    const cursorOutline = document.querySelector("[data-cursor-outline]");

    if (cursorDot && cursorOutline) {
        window.addEventListener("mousemove", function (e) {
            const posX = e.clientX;
            const posY = e.clientY;

            cursorDot.style.left = `${posX}px`;
            cursorDot.style.top = `${posY}px`;

            cursorOutline.animate({
                left: `${posX}px`,
                top: `${posY}px`
            }, { duration: 300, fill: "forwards" }); // Smoother outline follow with animation
        });

        // Add hover effects for cursor
        document.querySelectorAll('a, button, input[type="submit"], input[type="checkbox"], input[type="radio"], select, .suite-card-premium, .service-card, .dining-card').forEach(el => {
            el.addEventListener('mouseenter', () => {
                cursorOutline.style.transform = 'translate(-50%, -50%) scale(1.5)';
                cursorOutline.style.borderColor = 'var(--primary-color-dark)';
            });
            el.addEventListener('mouseleave', () => {
                cursorOutline.style.transform = 'translate(-50%, -50%) scale(1)';
                cursorOutline.style.borderColor = 'var(--primary-color)';
            });
        });
    }


    // 8. Footer Current Year
    const yearSpan = document.getElementById('current-year-footer-premium');
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }


    // 9. Animation Logic
    function initializeAnimations() {
        // Hero Animations (on load - these don't need IntersectionObserver)
        const heroAnimatedElements = document.querySelectorAll('#hero-premium [data-animation]');
        heroAnimatedElements.forEach(el => {
            const animationName = el.dataset.animation;
            const animationDelay = el.dataset.delay || '0s';
            const animationDuration = el.dataset.duration || '0.7s';

            el.style.transitionDelay = animationDelay;
            el.style.transitionDuration = animationDuration;
            
            el.classList.add('start-animation-' + animationName);
            void el.offsetWidth; // Force reflow
            el.classList.add('is-visible');
        });

        // Scroll Animations (for elements appearing on scroll)
        const scrollAnimatedElements = document.querySelectorAll('[data-animation-scroll]');
        if ("IntersectionObserver" in window) {
            const observer = new IntersectionObserver((entries, observerInstance) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const el = entry.target;
                        const animationName = el.dataset.animationScroll;
                        const animationDelay = el.dataset.delay || '0s';
                        const animationDuration = el.dataset.duration || '0.7s';

                        el.style.transitionDelay = animationDelay;
                        el.style.transitionDuration = animationDuration;
                        el.classList.add('start-animation-' + animationName);
                        void el.offsetWidth; // Force reflow
                        el.classList.add('is-visible');
                        
                        observerInstance.unobserve(el); // Animate only once
                    }
                });
            }, { threshold: 0.1 }); // Trigger when 10% of the element is visible

            scrollAnimatedElements.forEach(el => {
                observer.observe(el);
            });
        } else {
            // Fallback for browsers that don't support IntersectionObserver
            scrollAnimatedElements.forEach(el => {
                // Determine a default animation or just make visible
                const animationName = el.dataset.animationScroll || 'fadeInUp'; // Default to fadeInUp
                el.classList.add('start-animation-' + animationName); 
                void el.offsetWidth; // Reflow
                el.classList.add('is-visible'); // Make them visible
            });
        }
    }
    initializeAnimations(); // Call animation initialization

}); // End DOMContentLoaded


// In script.js, inside DOMContentLoaded
const yearSpan = document.getElementById('current-year-footer-premium');
const footerCopyrightContentHolder = document.querySelector('.footer-bottom-premium p [data-lang-key="footerCopyrightContent"]'); // If you use a span with data-key
const footerCopyrightP = document.querySelector('.footer-bottom-premium p');


if (yearSpan && footerCopyrightP) { // Check if footerCopyrightP exists
    // The year is already handled by a separate span, so we just need to set the text
    // The translation for "footerCopyrightContent" will be fetched by setPageLanguage
    // If you want to combine year + translated text here:
    // const currentLang = localStorage.getItem('pageLanguage') || 'am';
    // const copyrightText = translations[currentLang]?.footerCopyrightContent || "Default Copyright";
    // footerCopyrightP.innerHTML = `© ${new Date().getFullYear()} ${copyrightText}`;
    // For now, assuming the HTML structure with separate year span is preferred:
    if(yearSpan) yearSpan.textContent = new Date().getFullYear();
    // The text part will be handled by the normal translation process if it has data-lang-key
    // If the <p> itself has the data-lang-key="footerCopyright" then it will be replaced like:
    // "© 2023 ነገስታት | Negestat። ሁሉም መብቶች በህግ የተጠበቁ ናቸው።"
    // The current HTML has: <p><span id="current-year-footer-premium"></span> <span data-lang-key="footerCopyrightContent"></span></p>
    // So, ensure "footerCopyrightContent" key exists in translations.js for the text part.
}


            const customerLoginForm = document.getElementById('customer-login-form');
            if(customerLoginForm) {
                customerLoginForm.addEventListener('submit', (e) => {
                    e.preventDefault();
                    const email = document.getElementById('customer-login-email').value;
                    const password = document.getElementById('customer-login-password').value; // የይለፍ ቃልም መውሰድ ያስፈልጋል

                    // DEMO: Basic validation
                    // በእውነተኛ መተግበሪያ ይህ ከሰርቨር ጋር የሚገናኝ ኮድ ይሆናል
                    if (email === "user@example.com" && password === "password123") { 
                        showAuthMessage((translations[currentLang]?.loginSuccessCustomer || 'Login successful! Redirecting... (Demo)'), 'success');
                        setTimeout(() => { 
                            window.location.href = 'customer_dashboard.html'; // <<< እዚህ ላይ ነው የሚቀየረው
                        }, 1500);
                    } else {
                        showAuthMessage((translations[currentLang]?.loginErrorCustomer || 'Invalid email or password. (Demo)'), 'error');
                    }
                });
            }